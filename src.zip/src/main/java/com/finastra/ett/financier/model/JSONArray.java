package com.finastra.ett.financier.model;

public class JSONArray {

}
