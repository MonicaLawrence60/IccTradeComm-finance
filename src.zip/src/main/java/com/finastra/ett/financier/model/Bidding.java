package com.finastra.ett.financier.model;

public class Bidding {

    private BiddingDetails biddingDetails;

    public BiddingDetails getBiddingDetails() {
        return biddingDetails;
    }

    public void setBiddingDetails(BiddingDetails biddingDetails) {
        this.biddingDetails = biddingDetails;
    }

  
}
