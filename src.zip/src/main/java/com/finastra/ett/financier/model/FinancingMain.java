package com.finastra.ett.financier.model;

public class FinancingMain {

    private FinancingDetails financingDetails;

    public FinancingDetails getFinancingDetails() {
        return financingDetails;
    }

    public void setFinancingDetails(FinancingDetails financingDetails) {
        this.financingDetails = financingDetails;
    }
    
}
