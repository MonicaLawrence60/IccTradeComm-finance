package com.finastra.ett.financier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinancierApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinancierApplication.class, args);
	}

}
