package com.finastra.ett;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EttApplication {

	public static void main(String[] args) {
		SpringApplication.run(EttApplication.class, args);
	}

}
