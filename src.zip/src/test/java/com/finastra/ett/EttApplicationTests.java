package com.finastra.ett;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EttApplicationTests {

	@Test
	void contextLoads() {
	}

}
